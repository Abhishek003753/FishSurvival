﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyDestroy : MonoBehaviour {
	public GameObject strawberry;

	// Use this for initialization
	void Start () {
		
		
	}
	
	// Update is called once per frame
	void Update () {
		transform.RotateAround (strawberry.transform.position, Vector3.back, 7.5f);
		transform.Rotate (Vector3.forward * -30.0f, Space.World);
	}
	void OnCollisionEnter2D (Collision2D _obj){
		if (_obj.gameObject.name == "Player") {
			lifescript.life = lifescript.life - 1;
			if (lifescript.life == 0) {
				Destroy (_obj.gameObject);
			}
		}
	}
}
