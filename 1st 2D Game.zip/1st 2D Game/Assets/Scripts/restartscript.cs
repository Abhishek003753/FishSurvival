﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class restartscript : MonoBehaviour {
	public GameObject Deathpanel;
	public GameObject Gamepanel;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	public void OnButtonsClick(GameObject _gameobject){
		if (lifescript.life == 0) {
			Deathpanel.SetActive (true);
			Gamepanel.SetActive (false);
		}
		if(_gameobject.name == "Restart")
		{
			Invoke("Restart",1.2f);
		}
	}
	public void Restart(){
		SceneManager.LoadScene ("Level3");
}
}
