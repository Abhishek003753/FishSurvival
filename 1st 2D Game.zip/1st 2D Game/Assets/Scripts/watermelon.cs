﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class watermelon : MonoBehaviour {
	public GameObject watermelonNotCut, watermelonCut1,watermelonCut2,Audioobj;
	Rigidbody2D watermelonRigidbody;

	// Use this for initialization
	void Start () {
		watermelonRigidbody = GetComponent<Rigidbody2D>();
		watermelonRigidbody.gravityScale = 0;
	}

	void OnCollisionEnter2D(Collision2D _obj)
	{
		if (_obj.gameObject.tag=="Player") {
			watermelonNotCut.SetActive (false);
			watermelonCut1.SetActive (true);
			watermelonCut2.SetActive (true);
			Destroy (this.gameObject,0.3f);
			Audioobj.SetActive (true);
		}
	}

	void OnTriggerEnter2D(Collider2D _obj)
	{
		if (_obj.gameObject.name=="Player") {
			watermelonRigidbody.gravityScale = 1;
		}
	}
}
