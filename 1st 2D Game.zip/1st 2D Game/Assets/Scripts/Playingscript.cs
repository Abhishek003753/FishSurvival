﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playingscript : MonoBehaviour {
	public GameObject Gamepanel;
	public GameObject Menupanel;
	public GameObject Resume;
	public GameObject Pause;
	public void OnButtonsClick(GameObject _gameobject)
	{
		if (_gameobject.name == "Pause")
			Time.timeScale = 0;{
			Resume.SetActive (true);
		}
		if (_gameobject.name == "Resume") {
			Time.timeScale = 1;
			Pause.SetActive (true);
		}
		if (_gameobject.name == "Quit")
			Application.Quit ();
		if (_gameobject.name == "Exit") {
			Gamepanel.SetActive (false);
			Menupanel.SetActive (true);
			}
		if (_gameobject.name == "Start") {
			Gamepanel.SetActive (true);
			Menupanel.SetActive (false);
		}

	}

}
