﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DeathScript : MonoBehaviour {
	public GameObject Deathpanel;
	public GameObject Gamepanel;
	private void Awake()
	{
		Deathpanel.SetActive(false);
	}
	public void OnButtonsClick(GameObject _gameobject){
	/*	if (lifescript.life == 0) {
			Deathpanel.SetActive (true);
			Gamepanel.SetActive (false);
		} */
		if(_gameobject.name == "Restart")
		{
			Invoke("RestartButton",1.2f);
	}
}
 void RestartButton()
	{
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
		Gamepanel.SetActive (true);
	}
}
