﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stonedestroy : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void OnCollisionEnter2D (Collision2D _obj){
		if (_obj.gameObject.name == "Player") {
			lifescript.life = lifescript.life - 1;
			if (lifescript.life == 0) {
				//Destroy (_obj.gameObject);
			}
		}
	}
}