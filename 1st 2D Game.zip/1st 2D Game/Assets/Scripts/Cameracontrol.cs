﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cameracontrol : MonoBehaviour {
	public GameObject thePlayer;



	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
		if (thePlayer.activeSelf) {
			transform.position = new Vector3 (thePlayer.transform.position.x + 6.1f, transform.position.y, transform.position.z);
		}

	}
}
