﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Activationscript : MonoBehaviour {
	public GameObject Pause;
	public GameObject Exit;
	public GameObject Resume;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKey (KeyCode.Escape)) {
			Pause.SetActive (true);
			Exit.SetActive (true);
			}
		
	}
}
