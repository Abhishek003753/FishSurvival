﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playercontrol : MonoBehaviour {

	/*public Joystick joy;
	public float speed = 10f;
    float horizontal = 0f;*/
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		transform.Rotate (Vector3.forward * -14.0f, Space.World);
		if (Input.GetKey (KeyCode.RightArrow))
		    transform.Translate (Vector2.right * 6.5f * Time.deltaTime,Space.World);
		if (Input.GetKey (KeyCode.LeftArrow))
			transform.Translate(Vector2.left * 6.5f * Time.deltaTime, Space.World);
		if (Input.GetKey (KeyCode.Space))
			transform.Translate (Vector2.up * 10.0f * Time.deltaTime,Space.World);

		/*if(joy.Horizontal >= .2f)
		{
			transform.Translate(Vector2.right * 6.5f * Time.deltaTime, Space.World);
		} 
		else if(joy.Horizontal <= .2f)
		{
			transform.Translate(Vector2.left * 6.5f * Time.deltaTime, Space.World);
		}
		else
		{
			horizontal = 0f;
		}

		float vertical = joy.Vertical;

		if(vertical >= .5f)
		{
			transform.Translate(Vector2.up * 10.0f * Time.deltaTime, Space.World);
		} */
	
	}

	/*public void Left()
	{
		GetComponent<Rigidbody2D>().velocity = Vector2.left * 14f;
	}
	public void Right()
	{
		GetComponent<Rigidbody2D>().velocity = Vector2.right * 6.5f;
	}
	public void Jump()
	{
		GetComponent<Rigidbody2D>().velocity = Vector2.up * 10.0f;
	}
	public void PointerUp()
	{
		GetComponent<Rigidbody2D>().velocity = Vector2.zero;
	}*/

}
