﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class lifescript : MonoBehaviour {
	public static int life=1;
	public Text lifeDisplay;
	public GameObject deathPanel;
	[SerializeField]
	GameObject controleCanvas;
	private void Awake()
	{
		life = 1;
	}

	private void Start()
	{
	}
	void Update () {
		deathPanel = GameObject.Find("DeathPanel");
		lifeDisplay.text = life.ToString ();
		if (life==0) {
			//deathPanel.SetActive (true);
			controleCanvas.SetActive(false);
			Invoke ("showMenuPanel",0.1f);

		}
		
	}

	void showMenuPanel()
	{
		deathPanel.transform.GetChild(0).gameObject.SetActive (true);
	}
}
