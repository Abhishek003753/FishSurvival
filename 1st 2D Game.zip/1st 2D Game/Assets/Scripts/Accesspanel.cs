﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Accesspanel : MonoBehaviour {
	
	public GameObject Gamepanel;
	public GameObject Menupanel;
	public GameObject Resume;
	public GameObject Pause;
	public GameObject Optionspanel;
	public GameObject Settingspanel;
	public GameObject Controlpanel;
	public GameObject Exitpanel;
	public GameObject Quitpanel;
    public GameObject Deathpanel;
	

	static bool shouldMenuBe = true;

	public void OnButtonsClick(GameObject _gameobject)
	{
		if (_gameobject.name == "Start") {
			Menupanel.SetActive (false);
			Gamepanel.SetActive(true);
			shouldMenuBe = false;
		}
		if (_gameobject.name == "Pause") {
			Time.timeScale = 0;
			Pause.SetActive (false);
			Resume.SetActive (true);
		}
		if (_gameobject.name == "Resume") {
			Time.timeScale = 1;
			Resume.SetActive (false);
			Pause.SetActive (true);
		}
		if (_gameobject.name == "Exit") {
			Gamepanel.SetActive (false);
			Menupanel.SetActive (true);
			//Joystick.SetActive(false);
		}
		if (_gameobject.name == "Options") {
			Menupanel.SetActive (false);
			Optionspanel.SetActive (true);
		}
		if (_gameobject.name == "Settings") {
			Gamepanel.SetActive (false);
			Optionspanel.SetActive (false);
			Menupanel.SetActive (false);
			Settingspanel.SetActive (true);

		}
		if (_gameobject.name == "Back") {
			Controlpanel.SetActive (false);
			Optionspanel.SetActive (true);
		}
		if (_gameobject.name == "Back To Menu") {
			Optionspanel.SetActive (false);
			Menupanel.SetActive (true);
		}

		if (_gameobject.name == "Level 1") {
			Invoke ("loadlevel2", 1.2f);
		}
		if (_gameobject.name == "Controls") {
			Controlpanel.SetActive (true);
			Settingspanel.SetActive (false);
			Menupanel.SetActive (false);
			Settingspanel.SetActive (false);
			Optionspanel.SetActive (false);
		}
		if (_gameobject.name == "Back1") {
			Settingspanel.SetActive (false);
			Optionspanel.SetActive (true);
		}
		if (_gameobject.name == "Exit") {
			Exitpanel.SetActive (true);
			Controlpanel.SetActive (false);
			Settingspanel.SetActive (false);
			Menupanel.SetActive (false);
			Settingspanel.SetActive (false);
			Optionspanel.SetActive (false);
		}
		if (_gameobject.name == "Yes") {
			Exitpanel.SetActive (false);
			Menupanel.SetActive(true);
			Controlpanel.SetActive (false);
			Settingspanel.SetActive (false);
			Optionspanel.SetActive (false);
			Gamepanel.SetActive (false);
		}
		if (_gameobject.name == "No") {
			Exitpanel.SetActive (false);
			Controlpanel.SetActive (false);
			Settingspanel.SetActive (false);
			Menupanel.SetActive (false);
			Optionspanel.SetActive (false);
			Gamepanel.SetActive (true);
		}
		if (_gameobject.name == "Back2") {
			Menupanel.SetActive (true);
			Optionspanel.SetActive (false);
		}
		if (_gameobject.name == "Credits") {
			Exitpanel.SetActive (false);
			Controlpanel.SetActive (false);
			Settingspanel.SetActive (false);
			Menupanel.SetActive (false);
			Optionspanel.SetActive (false);
			Gamepanel.SetActive (false);
		}


		if (_gameobject.name == "Quit") {
			Quitpanel.SetActive (true);
			Exitpanel.SetActive (false);
			Controlpanel.SetActive (false);
			Menupanel.SetActive (false);
			Settingspanel.SetActive (false);
			Optionspanel.SetActive (false);
			Gamepanel.SetActive (false);
		}
		if (_gameobject.name == "Yes1") {
			Exitpanel.SetActive (false);
			Controlpanel.SetActive (false);
			Menupanel.SetActive (false);
			Settingspanel.SetActive (false);
			Optionspanel.SetActive (false);
			Gamepanel.SetActive (false);
			Quitpanel.SetActive (false);
			Application.Quit ();

		}
		if (_gameobject.name == "No1") {
			Exitpanel.SetActive (false);
			Controlpanel.SetActive (false);
			Settingspanel.SetActive (false);
			Menupanel.SetActive (true);
			Optionspanel.SetActive (false);
			Gamepanel.SetActive (false);
			Quitpanel.SetActive (false);
		}
		if (_gameobject.name == "Level 2") {
			Gamepanel.SetActive (true);
		}
        if (_gameobject.name == "Restart")
        {
            Invoke("loadlevel3", 1.2f);
        }

    }


	void loadlevel2()
	{
		SceneManager.LoadScene("Level1");
		Gamepanel.SetActive (true);
	}

    void loadlevel3()
    {
        SceneManager.LoadScene("Level3");
        Gamepanel.SetActive(true);
    }

	private void Update()
	{
		if (shouldMenuBe)
			Menupanel.SetActive(true);
		else
		{
			Menupanel.SetActive(false);
			Gamepanel.SetActive(true);
			//Joystick.SetActive(true);
		}
	}
}
