﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndScript : MonoBehaviour {
	public GameObject EndPanel;
	public GameObject Gamepanel;
	// Use this for initialization
	private void OnTriggerEnter2D(Collider2D collision)
	{
		if (collision.gameObject.tag == "Player") {
			Invoke ("End", 1f);
		}
	}
	void End()
	{
		EndPanel.SetActive (true);
		Gamepanel.SetActive (false);
		Application.Quit ();
	}
}
