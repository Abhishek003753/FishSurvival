﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dragoncripts : MonoBehaviour {
	public float _speed;

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
		transform.Translate (Vector3.left * _speed);
		if (this.transform.position.x > 228.64f) {
			_speed = -_speed;
			transform.localScale =  (new Vector2 (1.2f, 1f));
		}
		if (this.transform.position.x < 200.07f) {
			_speed = -_speed;
			transform.localScale = (new Vector2 (-1.2f, 1f));
		}

	}
	void OnCollisionEnter2D(Collision2D _obj){
		if (_obj.gameObject.name == "Player") {
			lifescript.life = lifescript.life - 1;
			if (lifescript.life == 0) {
				Destroy (_obj.gameObject);
			}
		}
	}
}
