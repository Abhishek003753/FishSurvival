﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {
	public GameObject thePlayer;



	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {

		transform.position = new Vector3 (thePlayer.transform.position.x+6.1f, transform.position.y, transform.position.z);


	}

}
