﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player2control : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		transform.Rotate (Vector3.forward * -14.0f, Space.World);
		if (Input.GetKey (KeyCode.RightArrow))
			transform.Translate (Vector2.right * 6.5f * Time.deltaTime,Space.World);
		if (Input.GetKey (KeyCode.LeftArrow))
			transform.Translate (Vector2.left * 6.5f * Time.deltaTime,Space.World);
		if (Input.GetKey (KeyCode.Space))
			transform.Translate (Vector2.up * 7.0f * Time.deltaTime,Space.World);
	}
}
