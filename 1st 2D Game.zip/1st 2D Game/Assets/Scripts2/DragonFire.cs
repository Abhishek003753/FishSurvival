﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragonFire : MonoBehaviour {
	public GameObject _bullet;
	public bool entered=false;
	public float r;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		r = Time.time;
		if (r%2<=0.01f) 
		{
			Instantiate (_bullet, transform.position, Quaternion.identity);
		}
	}

	void OnTriggerEnter2D(Collider2D _obj)
	{
		if (_obj.gameObject.tag=="Player") {
			entered = true;
		}
	}
}
