﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Block2movement : MonoBehaviour {
	public float _speed;

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
		transform.Translate (Vector3.up * _speed);
		if (this.transform.position.y > -6.21f) {
			_speed = -_speed;
		}
		if (this.transform.position.y < 5.88f) {
			_speed = -_speed;
		}

	}
	void OnCollisionEnter2D(Collision2D _obj){
		if (_obj.gameObject.name == "Player") {
			lifescript.life = lifescript.life - 1;
			if (lifescript.life == 0) {
				Destroy (_obj.gameObject);
			}
		}
	}
}
