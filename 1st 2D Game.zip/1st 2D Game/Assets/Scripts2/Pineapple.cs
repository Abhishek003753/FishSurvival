﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pineapple : MonoBehaviour {
	public GameObject PineappleNotCut, PineappleCut1,PineappleCut2;
	public AudioSource Obj;
	// Use this for initialization
	void Start () {
		
	}

	void OnCollisionEnter2D(Collision2D _obj)
	{
		if (_obj.gameObject.tag == "Player") {
			PineappleNotCut.SetActive (false);
			PineappleCut1.SetActive (true);
			PineappleCut2.SetActive (true);
			Destroy (this.gameObject, 0.15f);
			Obj.Play ();
		} else {
			Destroy (_obj.gameObject);
		}
	}
}
