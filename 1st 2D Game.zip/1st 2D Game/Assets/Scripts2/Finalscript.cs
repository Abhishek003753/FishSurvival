﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Finalscript : MonoBehaviour {
	public GameObject strawberry, strawSplash,Audioobj;

	// Use this for initialization


	void OnCollisionEnter2D(Collision2D _obj)
	{
		if (_obj.gameObject.tag=="Player") 
		{
			strawberry.SetActive (false);
			strawSplash.SetActive (true);
			Destroy(this.gameObject,0.3f);
			Audioobj.SetActive (true);
		}
	}

}
