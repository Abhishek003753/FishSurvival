﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy2Destroy : MonoBehaviour {

	public GameObject Pineapplenotcut;

	// Use this for initialization
	void Start () {


	}

	// Update is called once per frame
	void Update () {
		transform.RotateAround (Pineapplenotcut.transform.position, Vector3.back, 7.2f);
		transform.Rotate (Vector3.forward * -20.0f, Space.World);
	}
	void OnCollisionEnter2D (Collision2D _obj){
		if (_obj.gameObject.name == "Player") {
			lifescript.life = lifescript.life - 1;
			if (lifescript.life == 0) {
				Destroy (_obj.gameObject);
			}
		}
	}
}
