﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dragon2cripts : MonoBehaviour {

	public float _speed;

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
		transform.Translate (Vector3.down * _speed);
		if (this.transform.position.y > 8.52f) {
			_speed = -_speed;
		}
		if (this.transform.position.y < -1.78f) {
			_speed = -_speed;		
		}

	}
	void OnCollisionEnter2D(Collision2D _obj){
		if (_obj.gameObject.name == "Player") {
			lifescript.life = lifescript.life - 1;
			if (lifescript.life == 0) {
				Destroy (_obj.gameObject);
			}
		}
	}
}
